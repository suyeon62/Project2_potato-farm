package com.gamja_farm.common.exception;

public class WrongIdPwException extends RuntimeException{

	public WrongIdPwException(String message) {
		super(message);
	}
	
}
