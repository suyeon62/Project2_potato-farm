package com.gamja_farm.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MovieGenreDTO {
	
	private String movie_code;
	private String genre_1;
	private String genre_2;

}
